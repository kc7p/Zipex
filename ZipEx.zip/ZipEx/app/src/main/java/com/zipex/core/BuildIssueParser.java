package com.zipex.core;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class BuildIssueParser {
    private static final Pattern JAVA_OR_RESOURCE = Pattern.compile(
            "^(.+?\\.(?:java|xml|kt|kts|groovy|aidl|cpp|h)):"
                    + "(\\d+)(?::(\\d+))?:\\s*"
                    + "(?:(error|warning):\\s*)?(.*)$");

    private static final Pattern KOTLIN = Pattern.compile(
            "^e:\\s*(?:file://)?(.+?\\.kt):\\s*"
                    + "\\((\\d+),\\s*(\\d+)\\):\\s*(.*)$");

    public static final class Issue {
        public final String file;
        public final int line;
        public final int column;
        public final String severity;
        public final String message;

        private Issue(String file, int line, int column, String severity, String message) {
            this.file = file;
            this.line = line;
            this.column = column;
            this.severity = severity;
            this.message = message;
        }

        @Override
        public String toString() {
            if (file == null) {
                return severity + ": " + message
                        + " (compiler did not provide a file/line)";
            }
            String location = file + ":" + line;
            if (column > 0) location += ":" + column;
            return location + " - " + severity + ": " + message;
        }
    }

    private BuildIssueParser() {}

    public static List<Issue> parse(String buildOutput, Path projectRoot) {
        List<Issue> issues = new ArrayList<>();

        for (String rawLine : buildOutput.split("\\r?\\n")) {
            String line = rawLine.trim();

            Matcher kotlin = KOTLIN.matcher(line);
            if (kotlin.matches()) {
                issues.add(new Issue(
                        normalizePath(kotlin.group(1), projectRoot),
                        parseInt(kotlin.group(2)),
                        parseInt(kotlin.group(3)),
                        "error",
                        kotlin.group(4)));
                continue;
            }

            Matcher generic = JAVA_OR_RESOURCE.matcher(line);
            if (generic.matches()) {
                String severity = generic.group(4);
                if (severity == null || severity.isEmpty()) severity = "error";
                issues.add(new Issue(
                        normalizePath(generic.group(1), projectRoot),
                        parseInt(generic.group(2)),
                        parseInt(generic.group(3)),
                        severity,
                        generic.group(5)));
            }
        }

        if (issues.isEmpty() && buildOutput.contains("BUILD FAILED")) {
            issues.add(new Issue(null, 0, 0, "build failure",
                    "No source-file location was found. Review the Gradle "
                            + "failure details and task output."));
        }
        return issues;
    }

    private static String normalizePath(String rawPath, Path projectRoot) {
        String path = rawPath.replace('\\', '/');
        String root = projectRoot.toAbsolutePath().normalize().toString().replace('\\', '/');

        int rootPosition = path.indexOf(root + "/");
        if (rootPosition >= 0) {
            return path.substring(rootPosition + root.length() + 1);
        }
        while (path.startsWith("./")) {
            path = path.substring(2);
        }
        return path;
    }

    private static int parseInt(String value) {
        if (value == null || value.isEmpty()) return 0;
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException ignored) {
            return 0;
        }
    }
}
