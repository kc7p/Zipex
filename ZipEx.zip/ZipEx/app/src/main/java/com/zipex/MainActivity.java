package com.zipex;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.PowerManager;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final int PICK_ZIP = 1001;

    private TextView status;
    private File zipFile;
    private Spinner outputSpinner;
    private Spinner speedSpinner;
    private PowerManager powerManager;
    private PowerManager.OnThermalStatusChangedListener thermalListener;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 32, 28, 28);

        TextView title = new TextView(this);
        title.setText("ZipEx");
        title.setTextSize(28);
        layout.addView(title);

        status = new TextView(this);
        status.setText("Choose a ZIP containing an Android Gradle project.");
        status.setPadding(0, 20, 0, 20);
        layout.addView(status);

        Button pickButton = new Button(this);
        pickButton.setText("Choose project ZIP");
        pickButton.setOnClickListener(v -> chooseZip());
        layout.addView(pickButton);

        outputSpinner = addSpinner(layout, new String[]{"APK", "AAB"});
        speedSpinner = addSpinner(layout, new String[]{"Cool", "Balanced", "Fast"});

        Button buildButton = new Button(this);
        buildButton.setText("Build");
        buildButton.setOnClickListener(v -> startBuild());
        layout.addView(buildButton);

        setContentView(layout);

        powerManager = getSystemService(PowerManager.class);
        thermalListener = level -> runOnUiThread(() -> {
            if (level >= PowerManager.THERMAL_STATUS_SEVERE) {
                status.setText("Phone is hot. A build would be paused or stopped.");
            } else {
                status.setText("Thermal status: " + level);
            }
        });
        powerManager.addThermalStatusListener(thermalListener);
    }

    private Spinner addSpinner(LinearLayout parent, String[] values) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        parent.addView(spinner, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        return spinner;
    }

    private void chooseZip() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_ZIP);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != PICK_ZIP || resultCode != RESULT_OK
                || data == null || data.getData() == null) {
            return;
        }

        Uri uri = data.getData();
        File destination = new File(getFilesDir(), "project.zip");

        try (InputStream in = getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(destination)) {
            if (in == null) throw new IllegalStateException("Could not open ZIP.");
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) != -1) {
                out.write(buffer, 0, count);
            }
            zipFile = destination;
            status.setText("ZIP copied: " + destination.getName()
                    + ". Extraction is not implemented yet.");
        } catch (Exception e) {
            status.setText("Could not read ZIP: " + e.getMessage());
        }
    }

    private void startBuild() {
        if (zipFile == null) {
            status.setText("Choose a project ZIP first.");
            return;
        }

        File engine = new File(getFilesDir(), "engine/zipex-build");
        if (!engine.exists()) {
            status.setText("Build engine is not installed. This version of ZipEx "
                    + "does not include an on-device Gradle/JDK/SDK engine yet.");
            return;
        }

        String format = outputSpinner.getSelectedItem().toString();
        String speed = speedSpinner.getSelectedItem().toString();
        status.setText("Build engine found, but launching it is not implemented yet ("
                + format + ", " + speed + ").");
    }

    @Override
    protected void onDestroy() {
        if (powerManager != null && thermalListener != null) {
            powerManager.removeThermalStatusListener(thermalListener);
        }
        super.onDestroy();
    }
}
