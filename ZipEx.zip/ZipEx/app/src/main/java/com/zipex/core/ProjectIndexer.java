package com.zipex.core;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class ProjectIndexer {
    private static final int MAX_FILES = 100_000;
    private static final int MAX_DEPTH = 48;

    private static final Set<String> IGNORED_DIRECTORIES = new HashSet<>();
    static {
        IGNORED_DIRECTORIES.add(".git");
        IGNORED_DIRECTORIES.add(".gradle");
        IGNORED_DIRECTORIES.add(".idea");
        IGNORED_DIRECTORIES.add("build");
        IGNORED_DIRECTORIES.add("node_modules");
    }

    private ProjectIndexer() {}

    public static final class Result {
        public final Path workspace;
        public final Path projectRoot;
        public final List<String> relativeFiles;
        public final List<String> warnings;

        private Result(Path workspace, Path projectRoot,
                       List<String> relativeFiles, List<String> warnings) {
            this.workspace = workspace;
            this.projectRoot = projectRoot;
            this.relativeFiles = Collections.unmodifiableList(relativeFiles);
            this.warnings = Collections.unmodifiableList(warnings);
        }
    }

    public static Result scan(Path selectedWorkspace) throws IOException {
        Path workspace = selectedWorkspace.toRealPath();

        if (!Files.isDirectory(workspace)) {
            throw new IOException("Selected input is not a directory.");
        }

        List<String> files = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        List<Path> settingsRoots = new ArrayList<>();
        List<Path> buildRoots = new ArrayList<>();

        Files.walkFileTree(workspace, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                if (!dir.equals(workspace)) {
                    String name = dir.getFileName().toString().toLowerCase(Locale.ROOT);
                    if (IGNORED_DIRECTORIES.contains(name)) {
                        return FileVisitResult.SKIP_SUBTREE;
                    }
                    int depth = workspace.relativize(dir).getNameCount();
                    if (depth > MAX_DEPTH) {
                        warnings.add("Skipped deeply nested folder: " + relative(dir));
                        return FileVisitResult.SKIP_SUBTREE;
                    }
                }
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
                    throws IOException {
                if (Files.isSymbolicLink(file) || !attrs.isRegularFile()) {
                    return FileVisitResult.CONTINUE;
                }
                if (files.size() >= MAX_FILES) {
                    throw new IOException("Project has more than " + MAX_FILES
                            + " files; indexing stopped.");
                }

                files.add(relative(file));

                String name = file.getFileName().toString();
                Path parent = file.getParent();
                if (name.equals("settings.gradle") || name.equals("settings.gradle.kts")) {
                    settingsRoots.add(parent);
                } else if (name.equals("build.gradle") || name.equals("build.gradle.kts")) {
                    buildRoots.add(parent);
                }
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFileFailed(Path file, IOException error) {
                warnings.add("Could not read " + relative(file) + ": " + error.getMessage());
                return FileVisitResult.CONTINUE;
            }

            private String relative(Path path) {
                return workspace.relativize(path).toString().replace('\\', '/');
            }
        });

        Comparator<Path> shallowestFirst =
                Comparator.comparingInt(p -> workspace.relativize(p).getNameCount());

        Path projectRoot;
        if (!settingsRoots.isEmpty()) {
            projectRoot = Collections.min(settingsRoots, shallowestFirst);
        } else if (!buildRoots.isEmpty()) {
            projectRoot = Collections.min(buildRoots, shallowestFirst);
            warnings.add("No settings.gradle file found. Using the nearest "
                    + "build.gradle folder as the project root.");
        } else {
            throw new IOException("No settings.gradle or build.gradle file was found. "
                    + "This may not be a Gradle Android project.");
        }

        Collections.sort(files);
        return new Result(workspace, projectRoot, files, warnings);
    }
}
