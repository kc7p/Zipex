# ZipEx (starter project)

ZipEx is a starter Java Android app, minimum Android 10 (API 29).

## What works
- Pick a file and copy it into private app storage.
- APK/AAB and Cool/Balanced/Fast selectors.
- Thermal status monitoring (API 29+).
- ProjectIndexer: walks an extracted project folder, finds the Gradle root, skips build/cache folders.
- BuildIssueParser: turns compiler output into file, line, column, and message, or reports that no location was given.

## What is NOT implemented yet
- ZIP extraction (the copied ZIP is not unpacked yet).
- The on-device build engine (JDK, Gradle, Android SDK). The app detects an engine at files/engine/zipex-build but does not launch it.
- APK/AAB output and signing.

Building a full Gradle Android project on a phone is very hard and usually needs a Linux environment; some projects will not build on-device at all.

## Build this project
1. Open the folder in Android Studio (it will create the Gradle wrapper), or install Gradle 8.7+ and run `gradle wrapper`.
2. Run the Build APK task. Versions in build.gradle (AGP 8.5.2, compileSdk 34) can be changed to match your Android Studio.
3. Install the APK on an Android 10+ phone.
